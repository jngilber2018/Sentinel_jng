# Onboarding

The json file in this folder defines which workspaces need to have the Sentinel (SecurityInsights) solution installed. 