# Analytics Rules definition file

The JSON file in this folder contains all the alert rules that need to be deployed to the Sentinel environment. 

