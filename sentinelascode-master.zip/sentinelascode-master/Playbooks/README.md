# Playbooks

JSON files in this folder are ARM templates that define LogicApps that need to be deployed on a given Azure environment.