# Hunting Rules definition file

The config file in this folder specified the different Hunting queries that need to be created in the Sentinel environment.