# Workbooks

JSON files in this folder are ARM templates that define Workbooks that need to be deployed on a given Sentinel environment.